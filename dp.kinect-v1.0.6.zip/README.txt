****************************************************************************
	dp.kinect - a Cycling 74 Max Jitter external for Kinect based on the Microsoft Kinect SDK

	Copyright (C) 2011-2013 Dale Phurrough
	All rights reserved except for those documented in the dp.kinect terms at http://hidale.com.
	dp.kinect is distributed WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Includes some derivative work which was originally
	Copyright (C) 2013 Microsoft Corporation
	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at
		http://www.apache.org/licenses/LICENSE-2.0
	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
****************************************************************************

Full setup and documentation for dp.kinect is available at the wiki https://github.com/diablodale/dp.kinect/wiki